# __init__.py
from .summarize import summarize_project_folder

__all__ = ["summarize_project_folder"]
